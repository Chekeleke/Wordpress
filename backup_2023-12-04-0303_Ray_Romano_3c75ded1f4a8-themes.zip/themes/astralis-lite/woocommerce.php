<?php get_header(); ?>
<div class="container">
<div id="Tab-Naviagtion">
     <div class="left-content-wrap fullwidth">  
         <div class="SitePageStyle-2">              
			<?php woocommerce_content(); ?>
          </div><!-- .SitePageStyle-2-->           
    </div><!-- left-content-wrap-->   
</div><!-- #Tab-Naviagtion --> 
</div><!-- .container -->     
<?php get_footer(); ?>